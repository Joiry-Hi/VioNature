# VioNature 操作指南

> ## ⚠ 重要：游戏参数通过配置文件调节
>
> 本游戏几乎所有参数（200+ 项）都可通过 **`config/gameplay.cfg`** 自定义调整，包括但不限于：
> - 武器伤害、射速、弹速、爆炸半径、冷却时间
> - 敌人血量、刷新间隔、Boss 属性
> - 玩家移动速度、重力、跳跃高度
> - 地图类型与尺寸
> - 游戏模式（生存 / 教学 / 决斗 / Boss Rush）
>
> **修改方法**：用**记事本**（或任意纯文本编辑器）直接打开 `config/gameplay.cfg`，修改数值后保存，重启游戏即可生效。文件内每条参数均有英文注释说明其用途。
>
> > **常见问题**：从 zip 包解压出的文件可能带有"只读"属性，导致无法保存修改。
> > **解决**：右键点击 `gameplay.cfg` → **属性** → 取消勾选"只读" → 确定，即可正常编辑保存。
>
> 详细参数列表见文末「配置文件参考」章节。**强烈建议在游戏过程中按自己手感持续调整参数。**

---

## 基础操作

| 按键 | 功能 |
|------|------|
| **W A S D** | 前后左右移动 |
| **鼠标移动** | 瞄准（上下/左右旋转视角） |
| **鼠标左键** | 开火（按住连射） |
| **鼠标右键** | 武器特殊功能（蓄力/切换模式/长按指挥界面） |
| **鼠标滚轮** | 切换武器 / 调整纳米平台投放距离 / 调节闪现距离 |
| **空格键** | 跳跃 / 飞行模式下升高 |
| **Ctrl** | 飞行模式下降低高度 |
| **Shift** | 跑步（加速移动） |
| **数字键 1-8** | 直接切换武器 1-8 |
| **数字键 0** | 直接切换到神秘法杖（武器 9） |
| **P** | 隐藏/显示全部 HUD 和手持武器模型 |
| **F11** | 全屏 / 窗口切换 |
| **R** | 重新开始（重置游戏） |
| **Z** | 切换太空服（低重力模式）开/关 |
| **X** | 切换飞行装置 开/关 |
| **C** | 切换滑板 开/关 |

## 武器详解

VioNature 共有 **9 把武器**，每把武器都可以通过 **单击右键**（< 0.22 秒）在主/副模式之间切换。

### 1. 激光步枪 (LASER)
- **主模式：电浆连射** — 高速低伤害弹，射速极高（0.075s/发），适合持续压制
- **副模式：蓄力光束** — 按住右键 + 左键蓄力，松手发射穿透光束，伤害随蓄力条增长
- HUD 模式标识：无（默认为连射）

### 2. 火焰喷射器 (FLAME)
- **主模式：火焰弹 (F)** — 中距离弹道，半径随飞行时间膨胀，覆盖范围大。飞行时间与最大尺寸可通过配置调节（`flame_lifetime` / `flame_max_radius`）
- **副模式：热浪冲击波 (H)** — 近距离锥形持续伤害 + 强力击退，可弹飞敌方弹幕
- HUD 模式标识：F / H

### 3. 火箭筒 (ROCKET)
- **主模式：火箭弹** — 经典爆炸武器，命中/超时爆炸，附带火箭跳位移
- **副模式：无人机仓 (D)** — 发射一枚大口径榴弹式部署仓，弹道为抛物线，落地后固定 1 秒放出中型战斗无人机（四旋翼）。无人机自动寻找最近敌人，用机枪扫射（小型弹，无反弹，落地消失）+ 每 2 秒发射一枚火箭弹。无人机数量上限可通过配置调整（默认 10，无硬上限），每架持续 300 秒
- **无人机鸟群算法** — 无人机使用 boids 集群算法，具有分离（防止重叠）、凝聚（朝集群中心靠拢）、对齐（匹配集群速度）三种行为力，可在配置中分别调整各力的半径和强度
- **长按右键：无人机指挥界面 (> 0.22s)** — 手持火箭筒时，长按右键打开战术指挥界面（无暗化处理，非瞄准镜）。界面显示：无人机数量/上限、敌人数、目标距离、当前模式。所有敌人以正八面体线框标记附着在 3D 空间中，**不被障碍物遮挡**（X-ray 透视效果）。按 **鼠标左键** 设置无人机集合点
- **无人机集合点系统** — 设置集合点后，所有无人机进入"集结中"(ASSEMBLING) 状态，飞向集合点。全部到齐后进入"驻守"(HOLDING) 阶段，在集合点附近维持鸟群状态。驻守时间到后恢复"完成"(COMPLETE)，无人机恢复正常寻敌行为。驻守时间可通过 `drone_rally_hold_time` 配置。在驻守完成前重新设置集合点会刷新计时
- HUD 模式标识：D（火箭模式不显示）

### 4. 霰弹枪 (SHOTGUN)
- **主模式：霰弹 (P)** — 多发射击弹丸，附带后坐力位移（可叠加入移动链）
- **副模式：玻璃碎片 / 尘埃云 (G)** — 多发碎片出膛后受空气阻力逐渐减速，降到阈值速度后以鸟群算法聚拢成球形尘埃云，悬浮在配置高度持续造成伤害。出膛速度、阻力系数、云半径、分离距离、聚拢力度、成形时间等均可配置
- HUD 模式标识：P / G

### 5. 重力钉枪 (NAIL)
- **主模式：重力钉 (N)** — 命中或落地后产生牵引力场，持续拉拽周围敌人并造成伤害
- **副模式：黑洞手雷 (BH)** — 投掷黑洞，更大范围 + 更强吸力 + 中心"事件视界"秒杀区域。黑洞对玩家也有视界判定
- HUD 模式标识：N / BH

### 6. 无限手套 (GAUNT)
- **右键切换模式**：TimeStop (TS) | Blink (B)
- **TS 模式 — 左键：时间停止** — 冻结所有敌人、弹幕、力场
- **B 模式 — 左键：闪现传送** — 向面朝方向传送；**滚轮**对数调节距离（可配上下限）；落点处以 3 个相互垂直的虚线圆球标出预计位置；左下角 HUD 固定显示当前闪现距离
- HUD 模式标识：TS / B（时停激活中显示 T）

### 7. 朗基努斯之枪 (SPEAR)
- **主模式：投掷 (S)** — 高速红色双叉长枪，穿透伤害 + 玩家反向反冲（空中投掷可位移）
- **副模式：AT 推进 (T)** — 前方锥形伤害 + AT 立场橙黄色冲击波 + 强力后坐力位移。**推进期间短暂无敌**（时长可通过 `longinus_spear_thrust_invuln` 配置，默认 0.5 秒）
- HUD 模式标识：S / T

### 8. 纳米构造仪 (NANO)
- **主模式：纳米刃波 (B)** — 纳米机器人构筑新月形刃波，缓慢推进但伤害极高（1000/s），持续约 10s
- **副模式：纳米平台 (P)** — 在前方面向投射一块可站立的临时平台，持续 300s。滚轮可调整投放距离（0.35x~1.85x）
- HUD 模式标识：B / P

### 9. 神秘法杖 (STAFF)  — 按 0 键切换
- **主模式：诅咒法球 (C)** — 紫色追踪灵弹，命中敌人后施加 DoT 持续诅咒伤害，诅咒致死时释放灵魂法球链式反应。DPS 叠加倍率、追踪速率均可配置
- **副模式：秘法护盾 (S)** — 右键切换至护盾模式。左键部署球形护盾，阻挡敌人并推开，被敌方弹幕击中后碎裂释放紫色冲击波推开范围内敌人与弹幕。碎裂后进入冷却。**护盾激活后长按左键**可向场上所有 Essence 拾取物释放金色脉冲光波，揭示位置
- **魔法阵召唤** — 手持法杖、站立地面、静止时，**同时长按左右键** 3 秒完成施法，脚下生成五角星魔法阵 + 浮空正八面体框架。法阵自动吸收玩家弹幕并发射追踪魔化版本。法阵持续时间、半径、射击间隔均可配置
- HUD 模式标识：C / S / SA（护盾激活）/ SC（护盾冷却）

## 敌人图鉴

| 敌人 | 外观 | 血量 | 行为特征 |
|------|------|------|-----------|
| **Skitter** 爬行者 | 红色小球 | 1 | 基础近战敌人，直冲玩家，碰触造成伤害 |
| **Brute** 蛮兵 | 橙色大球 | 4 | 坦克型，移动慢但血量高 |
| **Wisp** 幽光 | 蓝色球 | 1.5 | 高速移动，呈波浪轨迹闪避，难以命中。第 25s 触发"幽光突袭"事件（×5） |
| **Spitter** 喷射者 | 绿色球 | 2.2 | 远程攻击，自动与玩家保持距离并射击。第 52s 触发"喷射伏击"（×3） |
| **Pouncer** 跃击者 | 紫色小球 | 1.8 | 蓄力后猛然弹射跳向玩家。第 82s 触发"跃击突袭"（×4） |
| **Harrier** 骚扰者 | 青色小球 | 1.4 | 空中悬停，正弦机动 + 远程射击。Wave 4 触发"骚扰群"事件（×3） |
| **Blinker** 闪烁者 | 粉色球 | 2.1 | 蓄力预警 → 瞬移到玩家侧后 → 高速冲刺。Wave 4 触发"闪烁打击"事件（×2） |
| **Boss** 几何领主 | 紫色大球 | 1000 | Wave 2 开始后第 50s 出现，发射追踪弹幕，血量低于 45% 后弹幕加速 |
| **Boss** 史莱姆王 | 绿色大球 | 200 | 第 100s 出现，地面移动 → 远跳/高跳 → 重砸冲击波。死亡分裂为 4 个小史莱姆，最多分裂 2 代 |
| **Duelist** 决斗者 | 金色球 | 100 | 仅在 Duel 模式出现，会使用玩家的全部 9 种武器，根据距离选择不同策略，会切换武器、蓄力、闪现、火箭跳 |
| **Boss** 伯利恒之星 | 金色正方体 + 六芒 | 200（可配） | 按地图类型出现在不同位置：小行星地图沿赤道轨道环绕，平面地图高悬中心上方，空心世界位于球心。攻击方式为巨型激光柱，分预警（无伤透明追踪）和伤害（低透明确认命中）两阶段，预警激光初始锁定玩家后缓慢旋转追踪，伤害阶段继续保持追踪。出现时间、轨道参数、激光数据均可配置 |
| **Dummy** 训练假人 | 灰色球 | 10（可配） | 仅 Tutorial 模式，不移动不攻击，用于测试武器伤害 |

## 拾取物

| 拾取物 | 效果 | 切换键 |
|--------|------|--------|
| **太空服**（蓝色） | 重力降至 24%（0.24x），可手动开关 | Z |
| **飞行装置**（青色） | 悬停飞行，空格升高 / Ctrl 降低，可手动开关 | X |
| **滑板**（绿色） | 地面摩擦大幅降低，保持高动量滑动，可手动开关 | C |
| **Essence**（彩虹星形八面体） | 额外生命 +1，HUD 下方显示六芒星数 | 自动拾取 |

太空服、飞行装置、滑板在开局时自动分布在地图半周位置。Essence 为定时刷新拾取物（默认 45 秒间隔），非开局必刷。

## Essence 生命系统

星形八面体彩虹拾取物在地图上定时刷新，拾取后增加额外生命：

- **显示**：HUD 顶部 TIME 下方以实心六芒星排列显示当前生命数（≤6 个星，>6 显示 +N）。六芒星随游戏时间循环变换色彩
- **触发**：受到致命伤害时，若拥有 Essence → 消耗 1 条生命 + 短暂无敌帧（默认 1.5 秒）+ 金色冲击波推开周围敌人与弹幕，**不死亡**
- **拾取**：碰触 Essence 拾取物 → 生命 +1，显示 "ESSENCE +1"
- **感应**：手持法杖、护盾模式激活时，**长按左键**向场上所有 Essence 位置持续释放金色脉冲光波，远距离可见
- 初始生命数、无敌时间、刷新间隔、地图上限均可通过配置调整

## 地图类型（通过 config/gameplay.cfg 的 `map_type` 切换）

| 地图 | 说明 |
|------|------|
| **circle** | 经典圆形平整竞技场，半径可调，外围散布装饰性柱子 |
| **square** / **square_obstacle** | 方形竞技场，含 8 个碰撞障碍物 + 7 个低层浮台 + 6 个高层浮台（最高 y≈29），垂直分层战斗空间 |
| **asteroid** | 球形小行星表面，重力指向球心，玩家站在球面外侧战斗 |
| **hollow_world** | 空心球壳内部，重力指向球壳外，玩家站在球壳内侧向球心战斗 |

## 游戏模式（通过 config/gameplay.cfg 的 `game_mode` 切换）

### Survival（生存模式）
- 波次递增难度，敌人刷新速度逐渐加快
- 第 25s、52s、82s 触发脚本化大规模敌袭事件
- 第 50s Boss "几何领主" 降临，第 100s "史莱姆王" 登场
- 击败 Boss 即视为通关，但游戏不结束，敌人持续刷新

### Tutorial（教学模式）
- 无敌人刷新，可自由探索地图、测试全部 9 把武器。有训练假人可供测试伤害
- 首次切换到每把武器时显示操作提示（主/副模式、特殊功能）
- 拾取装备后提示 Z/X/C 切换键
- 适合初次上手或熟悉新武器机制

### Duel（决斗模式）
- 1v1 对抗 AI "决斗者"
- 玩家有 2 层护甲（可配置），每层提供一次无敌帧（0.75s）
- AI 会使用全部 9 种武器 + 所有特殊能力（时间停止、闪现、火箭跳、法杖护盾等）
- 消灭决斗者即获胜

### Boss Rush 模式（通过 `boss_rush_mode = true` 开启）
- 仅 Boss 按各自设定时间生成，无普通敌人和脚本事件
- Geometry Lord 不再召唤护卫小怪
- 史莱姆王和伯利恒之星按各自 spawn_time 出现
- 对 Duel 模式无影响（duel 不受此参数控制）

## HUD 说明

```
TIME 12.3  SCORE 340  E 8  W SPEAR:S  G 0.24x  SUIT  FPS 60
WAVE 2                                    SLIME KING [=========     ]
DUEL: ARMOR 2
```

- **TIME**：生存时间（秒）
- **SCORE**：累计得分
- **E**：当前存活敌人数
- **W**：当前武器名:模式缩写
- **G**：当前重力倍率
- **状态词**：GROUND（地面）/ AIR（空中）/ SUIT（太空服）/ FLIGHT（飞行）/ SKATE（滑板）/ STOP（时停中）/ GOD（无敌模式）
- **六芒星**：TIME 下方，实心金色六芒星（色相循环）表示当前 Essence 生命数。受击无敌时变橙色。≤6 个星，>6 显示 +N
- **WAVE / 事件文字**：当前波次或最近的事件提示
- **Boss/决斗者血条**：仅显示 Boss 和决斗者
- **决斗者当前武器**：显示 Duelist 正在使用的武器

## 高级技巧

- **火箭跳**：对脚下发射火箭，利用爆炸冲量获得额外高度
- **空中位移链**：火箭跳 → 空中霰弹反冲 → 长枪反冲，可实现极高速度的三段位移
- **钩爪替代**：虽然游戏没有钩爪，但可以反冲向敌人发射重力钉 / 黑洞，利用引力井拉拽获得额外空中控制
- **纳米刃波钓鱼**：发射纳米刃波后，可以用闪现或火箭跳换位，让追逐的敌人撞入刀波范围
- **时停 combo**：时停 → 贴脸发射全部火箭 → 黑洞 → 解冻后瞬间爆发
- **无人机战术**：在不同位置部署无人机形成交叉火力，长按右键打开指挥界面设置集合点，让无人机集群驻守关键位置。对 Boss 战可在不同角度设置多个集合点，配合自身游击形成包围火力网
- **角动量保持**：在球形地图（asteroid / hollow_world）中，切线速度不受重力影响，可利用切线加速获得极高的环绕速度
- **AT 推进无敌帧**：朗基努斯之枪 AT 推进期间无敌，可用来穿越弹幕或硬吃 Boss 攻击
- **法阵阵地战**：在固定位置召唤魔法阵后，向法阵持续射击以填充吸收弹药，法阵会自动向附近敌人发射追踪弹幕
- **护盾感应 Essence**：手持法杖护盾模式时，长按左键向场上所有 Essence 位置释放金色脉冲波，快速定位拾取物
- **Essence 换血**：有额外生命时可以故意吃伤害触发无敌帧 + 冲击波推开周围敌人，创造输出窗口

---

## 配置文件参考

配置文件位于游戏目录下的 `config/gameplay.cfg`。下面列出主要参数分类及其作用。完整列表及最新默认值请直接查看该文件（内含英文注释）。

### 游戏模式与地图

| 参数 | 说明 | 可选值 |
|------|------|--------|
| `game_mode` | 游戏模式 | survival / tutorial / duel |
| `boss_rush_mode` | Boss Rush 模式开关 | true / false |
| `map_type` | 地图类型 | circle / square_obstacle / asteroid / hollow_world |

### 地图几何

| 参数 | 说明 |
|------|------|
| `circle_radius` | 圆形竞技场半径 |
| `asteroid_radius` | 小行星球面半径 |
| `asteroid_player_altitude` / `_enemy_altitude` | 小行星表面玩家/敌人高度 |
| `hollow_world_radius` | 空心球壳内半径 |
| `hollow_world_player_altitude` / `_enemy_altitude` | 球壳内玩家/敌人距壳距离 |

### 玩家移动

| 参数 | 说明 |
|------|------|
| `gravity` | 重力加速度 |
| `walk_speed` / `run_speed` | 步行/跑步速度 |
| `ground_acceleration` / `air_acceleration` | 地面/空中加速度 |
| `jump_speed` | 跳跃初速度 |

### 武器参数（部分关键项）

**激光步枪 (5a)**: `plasma_damage`, `plasma_speed`, `plasma_cooldown`, `laser_charge_damage`, `laser_beam_range` 等

**火焰喷射器 (5b)**: `flame_damage`, `flame_lifetime`（火焰弹飞行时间）, `flame_max_radius`（火焰弹最大尺寸）, `heatwave_damage`, `heatwave_force`, `heatwave_range`

**火箭筒 (5c)**: `rocket_impact_damage`, `rocket_explosion_damage`, `rocket_explosion_radius`, `rocket_jump_impulse`

**霰弹枪 (5d)**: `shotgun_pellet_damage`, `shotgun_pellet_count`, `glass_shard_damage`, `glass_shard_linger_time`, `glass_shard_cloud_radius` 等

**重力钉枪 (5e)**: `gravity_nail_damage`, `gravity_well_radius`, `gravity_well_force`, `black_hole_radius`, `black_hole_event_horizon_radius` 等

**无限手套 (5f)**: `blink_distance`, `blink_distance_min` / `_max`, `blink_clear_radius`, `time_stop_enabled`, `blink_enabled`

**朗基努斯之枪 (5g)**: `longinus_spear_damage`, `longinus_spear_speed`, `longinus_spear_impulse`, `longinus_spear_thrust_damage`, `longinus_spear_thrust_force`, `longinus_spear_thrust_range`, `longinus_spear_thrust_impulse`, `longinus_spear_shockwave_damage`, `longinus_spear_shockwave_force`, `longinus_spear_shockwave_radius`, `longinus_spear_thrust_invuln`（推进无敌时长，秒）

**纳米构造仪 (5h)**: `nano_blade_damage`, `nano_blade_lifetime`, `nano_blade_radius`, `nano_platform_range`, `nano_platform_lifetime` 等

**神秘法杖 (5i)**: `curse_orb_direct_damage`, `curse_orb_dps`, `curse_orb_max_stack_mult`, `curse_orb_speed`, `curse_orb_turn_rate`, `soul_orb_count`, `soul_orb_damage_scale`, `mystic_staff_shield_radius`, `mystic_staff_shield_cooldown`, `mystic_staff_shockwave_radius`, `magic_circle_lifetime`, `magic_circle_radius`, `magic_circle_fire_interval` 等

### Boss 参数

| 参数 | 说明 |
|------|------|
| `boss_spawn_time` | 几何领主出现时间（秒） |
| `boss_health` | 几何领主血量 |
| `slime_king_spawn_time` | 史莱姆王出现时间 |
| `slime_king_health` / `_radius` / `_speed` | 史莱姆王属性 |
| `slime_king_long_jump_speed` / `_high_jump_speed` / `_slam_speed` | 史莱姆王跳跃/重砸速度 |
| `slime_king_spherical_gravity` / `_surface_damping` | 球形地图重力与阻尼 |
| `slime_king_split_count` / `_max_generations` | 死亡分裂数量/代数 |
| `bethlehem_spawn_time` / `_health` | 伯利恒之星出现时间/血量 |
| `bethlehem_laser_duration` / `_cooldown` / `_damage` | 伯利恒之星激光参数 |

### 无人机 (section 9)

| 参数 | 说明 |
|------|------|
| `drone_max_count` | 同时存活的无人机上限 |
| `drone_lifetime` | 每架无人机存活时间 |
| `drone_bullet_damage` / `_speed` / `_shoot_interval` | 无人机机炮属性 |
| `drone_rocket_interval` / `_range` | 无人机火箭发射间隔/射程 |
| `drone_separation_radius` / `_force` | 鸟群分离力 |
| `drone_flocking_radius` / `_force` | 鸟群凝聚力 |
| `drone_rally_hold_time` | 集合点驻守时间 |

### Essence 生命系统 (section 10)

| 参数 | 说明 |
|------|------|
| `starting_essence` | 初始生命数（0 = 无额外生命） |
| `essence_hit_invuln` | 损失 Essence 后无敌时间（秒） |
| `essence_respawn_time` | Essence 拾取物重生间隔（秒） |
| `essence_max_on_map` | 地图上同时存在的 Essence 数量上限 |

### 调试与其他

| 参数 | 说明 |
|------|------|
| `invincible` | 无敌模式（true = GOD 模式，不受任何伤害） |
| `dummy_max_count` / `_health` | Tutorial 模式假人数量/血量 |

---

> **提示**：中文详细注释版配置文件位于 `config/gameplay_annotated.cfg`，可直接复制替换 `gameplay.cfg` 使用。
